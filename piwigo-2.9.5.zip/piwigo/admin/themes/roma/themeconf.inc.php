<?php
$themeconf = array(
  'name'  => 'roma',
  'parent' => 'default',
  'colorscheme' => 'dark',
);
?>
